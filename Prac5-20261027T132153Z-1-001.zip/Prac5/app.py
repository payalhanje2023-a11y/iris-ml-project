
from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

# Load the trained Linear Regression model
model = pickle.load(open("REPPModel.pkl", "rb"))


@app.route('/')
def home():
    return render_template("index.html")


@app.route('/predict', methods=['POST'])
def predict():

    try:
        # Get input values from HTML form
        height = float(request.form['height'])

        curb_weight = float(request.form['curb_weight'])

        engine_size = float(request.form['engine_size'])

        horsepower = float(request.form['horsepower'])


        # Arrange inputs in EXACTLY the same order
        # used during model training:
        #
        # ['height', 'curb-weight', 'engine-size', 'horsepower']

        input_data = np.array([[
            height,
            curb_weight,
            engine_size,
            horsepower
        ]])


        # Predict car price
        prediction = model.predict(input_data)


        # Display prediction
        prediction_text = (
            f"Predicted Car Price: "
            f"{prediction[0]:.2f}"
        )


        return render_template(
            "index.html",
            prediction_text=prediction_text
        )


    except ValueError:
        return render_template(
            "index.html",
            prediction_text="Please enter valid numerical values."
        )


if __name__ == "__main__":
    app.run(debug=True)

