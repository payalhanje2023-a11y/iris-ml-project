from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

# Load trained Logistic Regression model
model = pickle.load(open("BCModel.pkl", "rb"))

# Load the SAME scaler used during training
scaler = pickle.load(open("scaler.pkl", "rb"))


@app.route('/')
def home():
    return render_template("index.html")


@app.route('/predict', methods=['POST'])
def predict():

    # Get values from HTML form
    cgpa = float(request.form['cgpa'])
    iq = float(request.form['iq'])

    # Create 2D array
    new_student = np.array([[cgpa, iq]])

    # IMPORTANT: Apply scaling
    new_student_scaled = scaler.transform(new_student)

    # Predict using scaled data
    prediction = model.predict(new_student_scaled)

    # Convert prediction into text
    if prediction[0] == 1:
        result = "Student is Likely to be PLACED"
    else:
        result = "Student is NOT Likely to be PLACED"

    return render_template(
        "index.html",
        prediction_text=result
    )


if __name__ == "__main__":
    app.run(debug=True)